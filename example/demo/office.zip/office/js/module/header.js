(function(){
	var Module = {
		init: function(scope){
			
		}
	};

	define("office/view/header", function(){
		return Module;
	});
})(Qmik)