(function($){

	$.sun.config({
		vars:{
			version: $.now()
		}
	});
})(Qmik);